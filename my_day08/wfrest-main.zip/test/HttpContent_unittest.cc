#include <gtest/gtest.h>
#include "wfrest/HttpContent.h"

using namespace wfrest;

TEST(Urlencode, parse_post_kv)
{

}
