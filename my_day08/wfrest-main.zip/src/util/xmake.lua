target("util")
    set_kind("object")
    add_files("*.cc")
    add_packages("workflow")