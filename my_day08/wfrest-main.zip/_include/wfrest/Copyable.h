#ifndef WFREST_COPYABLE_H_
#define WFREST_COPYABLE_H_

namespace wfrest
{

class Copyable
{
protected:
    Copyable() = default;
    ~Copyable() = default;
};

} // namespace wfrest

#endif  // WFREST_COPYABLE_H_