#ifndef WFREST_MACRO_H_
#define WFREST_MACRO_H_

#define OUT

#endif // WFREST_MACRO_H_
